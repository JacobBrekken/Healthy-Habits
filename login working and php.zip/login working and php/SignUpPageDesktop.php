<?php
session_start();
	
	include("connection.php");
	include("functions.php");

	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password =$_POST['password'];

		if(!empty($user_name) && !empty($password))
		{
			//save to database
			$user_id = random_num(20);
			$query = "insert into users (user_id,user_name,password) values ('$user_id','$user_name','$password')";

			mysqli_query($con, $query);

			header("Location: LoginPageDesktop.php");
			die;
		}
		else
		{
			echo "Please enter valid information";
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1, width=device-width" />
		<title>Sign Up Page</title>
		<link rel="stylesheet" href="./global.css" />
		<link rel="stylesheet" href="./SignUpPageDesktop.css" />
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Inter:wght@700&display=swap"
		/>
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap"
		/>
	</head>
	<body>
		<div class="sign-up-page-desktop">
			<header class="navbar1">
				<div class="navbar-item"></div>
				<div class="text-container1">
					<img
						class="text-container-child"
						loading="lazy"
						alt=""
						src="./public/frame-2608168.svg"
					/>

					<h2 class="healthy-habits2">Healthy Habits</h2>
				</div>
				<div class="vector-icon">
					<div class="text-button15" id="textButton9">Home</div>
					<div class="text-button16" id="textButton10">About</div>
					<div class="text-button17" id="textButton11">Tracker</div>
					<div class="text-button18" id="textButton12">Nutrition</div>
					<div class="text-button19" id="textButton13">Workouts</div>
					<div class="icon-container1">
						<div class="text-button20" id="textButton14">Contact</div>
					</div>
					<button class="button9" id="button">
						<div class="form">Login</div>
					</button>
				</div>
			</header>
			<section class="sub-container-parent">
				<div class="sub-container5">
					<div class="frame-group">
						<div class="abstract-design-parent">
							<img
								class="abstract-design-icon1"
								alt=""
								src="./public/abstract-design.svg"
							/>

							<button class="icon-container2">
								<img class="icon7" alt="" src="./public/icon.svg" />
							</button>
						</div>
						<h1 class="heading1">Sign Up</h1>
					</div>
				</div>
				<div class="container5">
					<form class="form2" method="post">
						<div class="form-elements1">
							<div class="container6">
								<div class="sub-container6">
									<div class="label3">Full Name</div>
									<div class="input-field2">
										<input
											id="text"
											name="full_name"
											class="text3"
											placeholder="Enter your Name"
											type="text"
											required
										/>
									</div>
								</div>
							</div>
							<div class="sub-container7">
								<div class="label3">Email</div>
								<div class="input-field2">
									<input
										id="text"
										name="user_name"
										class="text3"
										placeholder="Enter your Email"
										type="text"
										required
									/>
								</div>
							</div>
							<div class="sub-container7">
								<div class="label3">Password</div>
								<div class="input-field2">
									<input
										id="text"
										name="password"
										class="text3"
										placeholder="Enter your Password"
										type="password"
										required
									/>
								</div>
							</div>
						</div>
						<button class="button10">
							<div class="already-have-an">Create an account</div>
						</button>
					</form>
					<div class="already-have-account">
						<div class="sub-container8" id="subContainer">
							<div class="already-have-an-container">
								<span class="already-have-an1">Already have an account? </span>
								<span class="sign-in">Sign In</span>
							</div>
						</div>
					</div>
					<div class="sub-container9">
						<div class="buttons-container2">
							<button class="button11">
								<img class="icon8" alt="" src="./public/icon-1.svg" />
							</button>
							<button class="button11">
								<img class="icon8" alt="" src="./public/icon-2.svg" />
							</button>
							<button class="button11">
								<img class="icon8" alt="" src="./public/icon-3.svg" />
							</button>
						</div>
					</div>
				</div>
			</section>
			<footer class="footer-section1">
				<div class="container8">
					<div class="logo1" id="logoContainer">
						<img
							class="text-container-child"
							alt=""
							src="./public/frame-2608168.svg"
						/>

						<h2 class="healthy-habits3">Healthy Habits</h2>
					</div>
					<div class="buttons-container3">
						<div class="text-button15" id="textButton">Home</div>
						<div class="text-button16" id="textButton1">About</div>
						<div class="text-button17" id="textButton2">Tracker</div>
						<div class="text-button24" id="textButton3">Nutrition</div>
						<div class="text-button25" id="textButton4">Workouts</div>
						<div class="text-button26" id="textButton5">Contact</div>
					</div>
					<div class="sub-container10" id="subContainer">
						<div class="footer-subcontainer">Go To Top</div>
						<button class="button14">
							<img
								class="heroicons-miniarrow-small-up1"
								alt=""
								src="./public/heroiconsminiarrowsmallup.svg"
							/>
						</button>
					</div>
				</div>
				<div class="container9">
					<div class="sub-container11">
						<div class="button15">
							<img class="icon11" alt="" src="./public/icon-4.svg" />

							<div class="text-button27">healthyhabits@my.unt.edu</div>
						</div>
						<button class="button16">
							<img class="icon11" alt="" src="./public/icon-5.svg" />

							<div class="text-button28">+91 91813 23 2309</div>
						</button>
						<button class="button16">
							<img class="icon11" alt="" src="./public/icon-6.svg" />

							<div class="text-button29">Denton, TX</div>
						</button>
					</div>
					<div class="subcontainer-text-footer">
						© 2024 Healthy Habits. All rights reserved.
					</div>
				</div>
			</footer>
		</div>

		<script>
			var textButton9 = document.getElementById("textButton9");
			if (textButton9) {
				textButton9.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton10 = document.getElementById("textButton10");
			if (textButton10) {
				textButton10.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton11 = document.getElementById("textButton11");
			if (textButton11) {
				textButton11.addEventListener("click", function (e) {
					window.location.href = "./TrackerPage.php";
				});
			}

			var textButton12 = document.getElementById("textButton12");
			if (textButton12) {
				textButton12.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton13 = document.getElementById("textButton13");
			if (textButton13) {
				textButton13.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton14 = document.getElementById("textButton14");
			if (textButton14) {
				textButton14.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var button = document.getElementById("button");
			if (button) {
				button.addEventListener("click", function (e) {
					window.location.href = "./LoginPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function (e) {
					window.location.href = "./LoginPageDesktop.php";
				});
			}

			var logoContainer = document.getElementById("logoContainer");
			if (logoContainer) {
				logoContainer.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton = document.getElementById("textButton");
			if (textButton) {
				textButton.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton1 = document.getElementById("textButton1");
			if (textButton1) {
				textButton1.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton2 = document.getElementById("textButton2");
			if (textButton2) {
				textButton2.addEventListener("click", function (e) {
					window.location.href = "./TeamPageDesktop.php";
				});
			}

			var textButton3 = document.getElementById("textButton3");
			if (textButton3) {
				textButton3.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton4 = document.getElementById("textButton4");
			if (textButton4) {
				textButton4.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton5 = document.getElementById("textButton5");
			if (textButton5) {
				textButton5.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					var anchor = document.querySelector("[data-scroll-to='header']");
					if (anchor) {
						anchor.scrollIntoView({ block: "start", behavior: "smooth" });
					}
				});
			}

			var frameParent = document.querySelector(".text-container1");
			if (frameParent) {
				frameParent.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var subContainer = document.querySelector(".sub-container10");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					window.scrollTo({
						top: 0,
						behavior: "smooth",
					});
				});
			}
		</script>
	</body>
</html>
