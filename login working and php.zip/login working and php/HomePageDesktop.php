<?php
session_start();

	include("connection.php");
	include("functions.php");

		$user_data = check_login($con);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1, width=device-width" />

		<link rel="stylesheet" href="./global.css" />
		<link rel="stylesheet" href="./HomePageDesktop.css" />
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Inter:wght@700&display=swap"
		/>
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap"
		/>
	</head>
	<body>
		<div class="home-page-desktop">
			<div class="main-content">
				<header class="navbar7">
					<div class="navbar-child4"></div>
					<div class="healthy-habits-text3">
						<img
							class="inner-frame-icon"
							loading="lazy"
							alt=""
							src="./public/frame-2608168.svg"
						/>

						<h2 class="healthy-habits14">Healthy Habits</h2>
					</div>
					<div class="text-container32">
						<div class="text-button107">Home</div>
						<div class="text-button108" id="textButton10">About</div>
						<div class="text-button109" id="textButton11">Tracker</div>
						<div class="text-button110" id="textButton12">Nutrition</div>
						<div class="text-button111" id="textButton13">Workouts</div>
						<div class="card24">
							<div class="text-button112" id="textButton14">Contact</div>
						</div>
						<button class="button68" id="button">
							<div class="shape11">Logout</div>
						</button>
					</div>
				</header>
				<div class="hero-section">
					<img
						class="image-icon23"
						loading="lazy"
						alt=""
						src="./public/image3@2x.png"
					/>

					<div class="container63">
						<div class="sub-container32">
							<div class="container64">
								<div class="sub-container33">
									<div class="container65">
										<h3 class="heading50">Transform Your Health with</h3>
									</div>
									<h1 class="heading51">
										Personalized Nutrition and Workout Plans
									</h1>
								</div>
								<div class="paragraph39">
									Welcome to Healthy Habits, your partner in achieving optimal
									health through personalized nutrition coaching. Our certified
									nutritionists are here to guide you on your weight loss
									journey, providing customized plans and ongoing support. Start
									your transformation today and experience the power of
									personalized nutrition coaching.
								</div>
							</div>
							<div class="buttons-container6">
								<button class="button69" id="button1">
									<div class="container66">Get Started Today</div>
								</button>
								<button class="button70">
									<div class="text24">Book a Demo</div>
								</button>
							</div>
						</div>
						<div class="sub-container34">
							<div class="container67">
								<img
									class="image-icon24"
									alt=""
									src="./public/image-14@2x.png"
								/>

								<img
									class="image-icon25"
									alt=""
									src="./public/image-24@2x.png"
								/>

								<img
									class="image-icon26"
									alt=""
									src="./public/image-34@2x.png"
								/>
							</div>
							<div class="name4">
								<b>430+</b>
								<span class="happy-customers">
									<span class="span"> </span>
									<span>Happy Customers</span>
								</span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<main class="sub-container-group">
				<section class="sub-container35">
					<div class="features-section">
						<div class="text-container33">
							<h1 class="heading52">Features</h1>
							<div class="paragraph40">
								Welcome to the Feature Section of Healthy Habits, your ultimate
								destination for all things nutrition and wellness.
							</div>
						</div>
						<div class="container68">
							<div class="sub-container36">
								<div class="card25">
									<div class="container69">
										<button class="icon-container11">
											<img class="icon44" alt="" src="./public/icon-7.svg" />
										</button>
										<div class="heading53">Personalized Nutrition Plans</div>
									</div>
									<div class="paragraph41">
										Receive a tailored nutrition plan designed specifically for
										your body and goals. Our certified nutritionists will
										consider your unique needs, dietary preferences, and health
										conditions to create a plan that suits you best.
									</div>
								</div>
								<div class="card25">
									<div class="container69">
										<div class="icon-container12">
											<img class="icon44" alt="" src="./public/icon-32.svg" />
										</div>
										<div class="heading54">Meal Planning and Recipes</div>
									</div>
									<div class="paragraph41">
										Access a vast collection of delicious and healthy recipes
										tailored to your dietary needs. Our nutritionists will also
										create personalized meal plans, making it easier for you to
										stay on track and enjoy nutritious meals.
									</div>
								</div>
							</div>
							<div class="sub-container36">
								<div class="card25">
									<div class="container69">
										<button class="icon-container11">
											<img class="icon44" alt="" src="./public/icon-22.svg" />
										</button>
										<div class="heading55">Food Tracking and Analysis</div>
									</div>
									<div class="paragraph41">
										Effortlessly track your food intake using our user-friendly
										app. Our nutritionists will analyze your data to provide
										insights into your eating habits, help you identify areas
										for improvement, and make personalized recommendations.
									</div>
								</div>
								<div class="card25">
									<div class="container69">
										<button class="icon-container11">
											<img class="icon47" alt="" src="./public/icon-33.svg" />
										</button>
										<div class="heading56">Workout Programs</div>
									</div>
									<div class="paragraph41">
										Achieving sustainable results requires more than just a diet
										plan. Our workout plans will help you to develop healthy
										habits, address emotional eating, and provide strategies to
										overcome obstacles along the way.
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<section class="blogs-section">
					<div class="text-container33">
						<h1 class="heading52">Our Blogs</h1>
						<div class="paragraph45">
							Our blog is a treasure trove of informative and engaging articles
							written by our team of nutritionists, dietitians, and wellness
							experts. Here's what you can expect from our blog.
						</div>
					</div>
					<div class="container73">
						<div class="sub-container38">
							<div class="card29">
								<img
									class="image-icon27"
									alt=""
									src="./public/image-42@2x.png"
								/>

								<div class="container74">
									<div class="text-container35">
										<div class="text25">Weight Loss</div>
										<h3 class="heading58">
											The Benefits of Hydration for Weight Loss
										</h3>
									</div>
									<div class="paragraph46">
										Discover how staying hydrated can support your weight loss
										goals and improve overall health.
									</div>
									<div class="sub-container39">
										<div class="container75">
											<img
												class="image-icon28"
												alt=""
												src="./public/image-52@2x.png"
											/>

											<div class="text-container36">
												<div class="name5">Emily Johnson</div>
												<div class="image">23 May 2023 - 5 min read</div>
											</div>
										</div>
										<div class="container76">
											<button class="icon-container15">
												<img class="icon48" alt="" src="./public/icon-41.svg" />
											</button>
											<div class="icon-container16">
												<img class="icon48" alt="" src="./public/icon-51.svg" />
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card29">
								<img
									class="image-icon27"
									alt=""
									src="./public/image-62@2x.png"
								/>

								<div class="container74">
									<div class="text-container35">
										<div class="text25">Understanding Macronutrients</div>
										<h3 class="heading58">Carbohydrates, Proteins, and Fats</h3>
									</div>
									<div class="paragraph46">
										Get a comprehensive understanding of macronutrients and
										their role in your diet for optimal health and weight
										management.
									</div>
									<div class="sub-container39">
										<div class="container75">
											<img
												class="image-icon28"
												alt=""
												src="./public/image-72@2x.png"
											/>

											<div class="text-container36">
												<div class="name5">Mark Wilson</div>
												<div class="image">23 May 2023 - 5 min read</div>
											</div>
										</div>
										<div class="container76">
											<button class="icon-container15">
												<img class="icon48" alt="" src="./public/icon-41.svg" />
											</button>
											<div class="icon-container16">
												<img class="icon48" alt="" src="./public/icon-51.svg" />
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="sub-container38">
							<div class="card29">
								<img
									class="image-icon27"
									alt=""
									src="./public/image-81@2x.png"
								/>

								<div class="container74">
									<div class="text-container35">
										<div class="text25">Mindful Eating</div>
										<h3 class="heading58">
											Cultivating a Healthy Relationship with Food
										</h3>
									</div>
									<div class="paragraph46">
										Learn how practicing mindful eating can help you develop a
										healthier relationship with food and improve your overall
										well-being.
									</div>
									<div class="sub-container39">
										<div class="container75">
											<img
												class="image-icon28"
												alt=""
												src="./public/image-91@2x.png"
											/>

											<div class="text-container36">
												<div class="name5">Sarah Thompson</div>
												<div class="image">23 May 2023 - 5 min read</div>
											</div>
										</div>
										<div class="container76">
											<button class="icon-container15">
												<img class="icon48" alt="" src="./public/icon-41.svg" />
											</button>
											<div class="icon-container16">
												<img class="icon48" alt="" src="./public/icon-51.svg" />
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card29">
								<img
									class="image-icon27"
									alt=""
									src="./public/image-101@2x.png"
								/>

								<div class="container74">
									<div class="text-container35">
										<div class="text25">Healthy Snacks on the Go</div>
										<h3 class="heading58">Quick and Nutritious Options</h3>
									</div>
									<div class="paragraph46">
										Explore a variety of convenient and healthy snack ideas to
										keep you fueled throughout the day.
									</div>
									<div class="sub-container39">
										<div class="container75">
											<img
												class="image-icon28"
												alt=""
												src="./public/image-111@2x.png"
											/>

											<div class="text-container36">
												<div class="name5">Emily Johnson</div>
												<div class="image">23 May 2023 - 5 min read</div>
											</div>
										</div>
										<div class="container76">
											<button class="icon-container15">
												<img class="icon48" alt="" src="./public/icon-41.svg" />
											</button>
											<div class="icon-container16">
												<img class="icon48" alt="" src="./public/icon-51.svg" />
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<section class="container-footer">
					<h1 class="heading62">Our Testimonials</h1>
					<div class="paragraph50">
						Our satisfied clients share their success stories and experiences on
						their journey to better health and well-being.
					</div>
				</section>
				<section class="text-link-button">
					<div class="items-container3">
						<div class="card33">
							<div class="container86">
								<img class="icon56" alt="" src="./public/icon-121.svg" />

								<div class="paragraph51">
									I can't thank Healthy Habits enough for their personalized
									nutrition coaching. It has completely transformed my approach
									to food and helped me shed those extra pounds. Highly
									recommended!
								</div>
							</div>
							<div class="line26"></div>
							<div class="container87">
								<img
									class="image-icon35"
									alt=""
									src="./public/image-121@2x.png"
								/>

								<div class="name9">Jennifer Anderson</div>
							</div>
						</div>
						<div class="card33">
							<div class="container86">
								<img class="icon56" alt="" src="./public/icon-121.svg" />

								<div class="paragraph51">
									Healthy Habits has been a game-changer for me. The expert
									guidance and support I received from their team made my weight
									loss journey so much easier. Thank you!
								</div>
							</div>
							<div class="line26"></div>
							<div class="container89">
								<img
									class="image-icon35"
									alt=""
									src="./public/image-131@2x.png"
								/>

								<div class="name10">Robert Johnson</div>
							</div>
						</div>
						<div class="card33">
							<div class="container86">
								<img class="icon56" alt="" src="./public/icon-121.svg" />

								<div class="paragraph51">
									I had struggled with my weight for years until I found Healthy
									Habits. Their personalized approach and tailored nutrition
									plan made all the difference. I've never felt better!
								</div>
							</div>
							<div class="line26"></div>
							<div class="container87">
								<img
									class="image-icon35"
									alt=""
									src="./public/image-141@2x.png"
								/>

								<div class="name11">Emily Davis</div>
							</div>
						</div>
					</div>
				</section>
				<div class="footer-section-container">
					<button class="button71">
						<img class="icon59" alt="" src="./public/icon-15.svg" />
					</button>
					<div class="indicators">
						<div class="shape12"></div>
						<div class="shape13"></div>
						<div class="shape13"></div>
						<div class="shape13"></div>
						<div class="shape13"></div>
					</div>
					<button class="button71">
						<img class="icon59" alt="" src="./public/icon-16.svg" />
					</button>
				</div>
			</main>
			<footer class="footer-section8">
				<div class="container92">
					<div class="frame-header">
						<div class="logo7" id="logoContainer">
							<img
								class="inner-frame-icon"
								alt=""
								src="./public/frame-2608168.svg"
							/>

							<h2 class="healthy-habits15">Healthy Habits</h2>
						</div>
					</div>
					<div class="footer-sub-container">
						<div class="text-button113" id="textButton">Home</div>
						<div class="text-button108" id="textButton1">About</div>
						<div class="text-button109" id="textButton2">Tracker</div>
						<div class="text-button116" id="textButton3">Nutrition</div>
						<div class="text-button117" id="textButton4">Workouts</div>
						<div class="text-button118" id="textButton5">Contact</div>
					</div>
					<div class="sub-container44" id="subContainer">
						<div class="indicators-shape">Go To Top</div>
						<button class="button73">
							<img
								class="heroicons-miniarrow-small-up7"
								alt=""
								src="./public/heroiconsminiarrowsmallup.svg"
							/>
						</button>
					</div>
				</div>
				<div class="container93">
					<div class="sub-container45">
						<div class="button74">
							<img class="icon48" alt="" src="./public/icon-4.svg" />

							<div class="text-button119">healthyhabits@my.unt.edu</div>
						</div>
						<button class="button75">
							<img class="icon48" alt="" src="./public/icon-5.svg" />

							<div class="text-button120">+91 91813 23 2309</div>
						</button>
						<button class="button75">
							<img class="icon48" alt="" src="./public/icon-6.svg" />

							<div class="text-button121">Denton, TX</div>
						</button>
					</div>
					<div class="main-footer-buttons">
						© 2024 Healthy Habits. All rights reserved.
					</div>
				</div>
			</footer>
		</div>

		<script>
			var textButton10 = document.getElementById("textButton10");
			if (textButton10) {
				textButton10.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton11 = document.getElementById("textButton11");
			if (textButton11) {
				textButton11.addEventListener("click", function (e) {
					window.location.href = "./TrackerPage.php";
				});
			}

			var textButton12 = document.getElementById("textButton12");
			if (textButton12) {
				textButton12.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton13 = document.getElementById("textButton13");
			if (textButton13) {
				textButton13.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton14 = document.getElementById("textButton14");
			if (textButton14) {
				textButton14.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var button = document.getElementById("button");
			if (button) {
				button.addEventListener("click", function (e) {
					window.location.href = "./logout.php";
				});
			}

			var button1 = document.getElementById("button1");
			if (button1) {
				button1.addEventListener("click", function (e) {
					window.location.href = "./LoginPageDesktop.php";
				});
			}

			var logoContainer = document.getElementById("logoContainer");
			if (logoContainer) {
				logoContainer.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton = document.getElementById("textButton");
			if (textButton) {
				textButton.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton1 = document.getElementById("textButton1");
			if (textButton1) {
				textButton1.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton2 = document.getElementById("textButton2");
			if (textButton2) {
				textButton2.addEventListener("click", function (e) {
					window.location.href = "./TeamPageDesktop.php";
				});
			}

			var textButton3 = document.getElementById("textButton3");
			if (textButton3) {
				textButton3.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton4 = document.getElementById("textButton4");
			if (textButton4) {
				textButton4.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton5 = document.getElementById("textButton5");
			if (textButton5) {
				textButton5.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					var anchor = document.querySelector("[data-scroll-to='header']");
					if (anchor) {
						anchor.scrollIntoView({ block: "start", behavior: "smooth" });
					}
				});
			}
			var subContainer = document.querySelector(".sub-container44");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					window.scrollTo({
						top: 0,
						behavior: "smooth",
					});
				});
			}
		</script>
	</body>
</html>
