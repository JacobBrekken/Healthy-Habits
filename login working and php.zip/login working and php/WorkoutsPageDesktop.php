<?php
session_start();
	
	include("connection.php");
	include("functions.php");

		$user_data = check_login($con);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1, width=device-width" />

		<link rel="stylesheet" href="./global.css" />
		<link rel="stylesheet" href="./WorkoutsPageDesktop.css" />
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Inter:wght@700&display=swap"
		/>
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap"
		/>
	</head>
	<body>
		<div class="workouts-page-desktop">
			<header class="navbar3">
				<div class="frame-div"></div>
				<div class="abstract-design-vector-parent">
					<img
						class="footer-navbar-icon"
						loading="lazy"
						alt=""
						src="./public/frame-2608168.svg"
					/>

					<h2 class="healthy-habits6">Healthy Habits</h2>
				</div>
				<div class="heading-text">
					<div class="text-button45" id="textButton9">Home</div>
					<div class="text-button46" id="textButton10">About</div>
					<div class="text-button47" id="textButton11">Tracker</div>
					<div class="text-button48" id="textButton12">Nutrition</div>
					<div class="text-button49">Workouts</div>
					<div class="tabs-container-text">
						<div class="text-button50" id="textButton14">Contact</div>
					</div>
					<button class="button31" id="button">
						<div class="line-image-container">Logout</div>
					</button>
				</div>
			</header>
			<main class="line-divider">
				<section class="sub-container19">
					<div class="image-text">
						<div class="icon-container4">
							<img
								class="icon24"
								loading="lazy"
								alt=""
								src="./public/icon.svg"
							/>
						</div>
						<div class="tab-frame">
							<img
								class="abstract-design-icon5"
								alt=""
								src="./public/abstract-design.svg"
							/>

							<h1 class="heading4">Workouts</h1>
						</div>
					</div>
					<div class="paragraph2">
						Welcome to the Workout section of Healthy Habits, your trusted
						source for insightful articles, tips, and expert advice on nutrition
						and wellness. Here, we strive to provide you with engaging and
						informative content that will inspire and empower you to make
						informed decisions about your health. Explore our blog to discover a
						wealth of resources that cover a wide range of topics related to
						nutrition, fitness, and overall well-being.
					</div>
				</section>
				<div class="container19">
					<div class="footer-logo-container">
						<div class="line"></div>
						<div class="line-parent">
							<div class="line1"></div>
							<div class="line2"></div>
						</div>
					</div>
					<div class="line3"></div>
					<div class="button32">
						<div class="card">
							<div class="text-container-wrapper">
								<div class="text-container3">
									<div class="heading5">Fitness and Exercise</div>
								</div>
							</div>
							<div class="line-group">
								<div class="line4"></div>
								<div class="image-container">
									<img
										class="image-icon"
										loading="lazy"
										alt=""
										src="./public/image@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent1">
								<div class="heading-parent">
									<div class="heading6">
										Cardio vs. Strength Training: Which Is Better for Weight
										Loss?
									</div>
									<div class="paragraph3">
										Explore the benefits of both cardio and strength training
										exercises for weight loss. Find out how to combine them
										effectively to maximize your results.
									</div>
								</div>
								<button class="button33">
									<div class="text11">Read More</div>
								</button>
							</div>
						</div>
						<div class="line5"></div>
						<div class="card1">
							<div class="text-container-wrapper">
								<div class="text-container3">
									<div class="heading5">Fitness and Exercise</div>
								</div>
							</div>
							<div class="line-group">
								<div class="line4"></div>
								<div class="image-container">
									<img
										class="image-icon"
										alt=""
										src="./public/image-1@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent1">
								<div class="heading-parent">
									<div class="heading6">
										Building a Home Workout Routine: Tips and Best Practices
									</div>
									<div class="paragraph3">
										Discover how to create an effective workout routine at home.
										Learn about equipment options, exercise techniques, and ways
										to stay motivated.
									</div>
								</div>
								<button class="button33">
									<div class="text11">Read More</div>
								</button>
							</div>
						</div>
					</div>
					<div class="line3"></div>
					<div class="button35">
						<div class="card2">
							<div class="text-container-wrapper">
								<div class="text-container3">
									<div class="heading9">Mindset and Motivation</div>
								</div>
							</div>
							<div class="line-group">
								<div class="line4"></div>
								<div class="image-container">
									<img
										class="image-icon"
										alt=""
										src="./public/image-2@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent1">
								<div class="heading-parent">
									<div class="heading6">
										Developing a Positive Body Image and Self-Confidence
									</div>
									<div class="paragraph3">
										Explore techniques for cultivating a positive body image and
										improving self-confidence. Learn how to embrace your body
										and appreciate your unique qualities.
									</div>
								</div>
								<button class="button33">
									<div class="text11">Read More</div>
								</button>
							</div>
						</div>
						<div class="card3">
							<div class="text-container-wrapper">
								<div class="text-container3">
									<div class="heading9">Mindset and Motivation</div>
								</div>
							</div>
							<div class="line-group">
								<div class="line4"></div>
								<div class="image-container">
									<img
										class="image-icon"
										alt=""
										src="./public/image-3@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent1">
								<div class="heading-parent">
									<div class="heading6">
										Overcoming Self-Sabotage in Your Weight Loss Journey
									</div>
									<div class="paragraph3">
										Identify self-sabotaging behaviors and learn strategies to
										overcome them. Discover how to shift your mindset and
										develop healthier habits.
									</div>
								</div>
								<button class="button33">
									<div class="text11">Read More</div>
								</button>
							</div>
						</div>
						<div class="line10"></div>
					</div>
				</div>
			</main>
			<footer class="footer-section3">
				<div class="container20">
					<div class="logo3" id="logoContainer">
						<img
							class="footer-navbar-icon"
							alt=""
							src="./public/frame-2608168.svg"
						/>

						<h2 class="healthy-habits7">Healthy Habits</h2>
					</div>
					<div class="text-button51">
						<div class="text-button45" id="textButton">Home</div>
						<div class="text-button46" id="textButton1">About</div>
						<div class="text-button47" id="textButton2">Tracker</div>
						<div class="text-button55" id="textButton3">Nutrition</div>
						<div class="text-button56" id="textButton4">Workouts</div>
						<div class="text-button57" id="textButton5">Contact</div>
					</div>
					<div class="sub-container20" id="subContainer">
						<div class="button38">Go To Top</div>
						<button class="button39">
							<img
								class="heroicons-miniarrow-small-up3"
								alt=""
								src="./public/heroiconsminiarrowsmallup.svg"
							/>
						</button>
					</div>
				</div>
				<div class="container21">
					<div class="sub-container21">
						<div class="button40">
							<img class="icon25" alt="" src="./public/icon-4.svg" />

							<div class="text-button58">healthyhabits@my.unt.edu</div>
						</div>
						<button class="button41">
							<img class="icon25" alt="" src="./public/icon-5.svg" />

							<div class="text-button59">+91 91813 23 2309</div>
						</button>
						<button class="button41">
							<img class="icon25" alt="" src="./public/icon-6.svg" />

							<div class="text-button60">Denton, TX</div>
						</button>
					</div>
					<div class="button-group">
						© 2024 Healthy Habits. All rights reserved.
					</div>
				</div>
			</footer>
		</div>

		<script>
			var textButton9 = document.getElementById("textButton9");
			if (textButton9) {
				textButton9.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton10 = document.getElementById("textButton10");
			if (textButton10) {
				textButton10.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton11 = document.getElementById("textButton11");
			if (textButton11) {
				textButton11.addEventListener("click", function (e) {
					window.location.href = "./TrackerPage.php";
				});
			}

			var textButton12 = document.getElementById("textButton12");php
			if (textButton12) {
				textButton12.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton14 = document.getElementById("textButton14");
			if (textButton14) {
				textButton14.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var button = document.getElementById("button");
			if (button) {
				button.addEventListener("click", function (e) {
					window.location.href = "./logout.php";
				});
			}

			var logoContainer = document.getElementById("logoContainer");
			if (logoContainer) {
				logoContainer.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton = document.getElementById("textButton");
			if (textButton) {
				textButton.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton1 = document.getElementById("textButton1");
			if (textButton1) {
				textButton1.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton2 = document.getElementById("textButton2");
			if (textButton2) {
				textButton2.addEventListener("click", function (e) {
					window.location.href = "./TrackerPage.php";
				});
			}

			var textButton3 = document.getElementById("textButton3");
			if (textButton3) {
				textButton3.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton4 = document.getElementById("textButton4");
			if (textButton4) {
				textButton4.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton5 = document.getElementById("textButton5");
			if (textButton5) {
				textButton5.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					var anchor = document.querySelector("[data-scroll-to='header']");
					if (anchor) {
						anchor.scrollIntoView({ block: "start", behavior: "smooth" });
					}
				});
			}

			var frameParent = document.querySelector(
				".abstract-design-vector-parent"
			);
			if (frameParent) {
				frameParent.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var subContainer = document.querySelector(".sub-container20");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					window.scrollTo({
						top: 0,
						behavior: "smooth",
					});
				});
			}
		</script>
	</body>
</html>
