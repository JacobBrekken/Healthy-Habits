<?php
session_start();
	
	include("connection.php");
	include("functions.php");

		$user_data = check_login($con);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1, width=device-width" />

		<link rel="stylesheet" href="./global.css" />
		<link rel="stylesheet" href="./NutritionPageDesktop.css" />
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Inter:wght@700&display=swap"
		/>
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap"
		/>
	</head>
	<body>
		<div class="nutrition-page-desktop">
			<header class="navbar4">
				<div class="navbar-child1"></div>
				<div class="frame-child1">
					<img
						class="abstract-design-vector2"
						loading="lazy"
						alt=""
						src="./public/frame-2608168.svg"
					/>

					<h2 class="healthy-habits8">Healthy Habits</h2>
				</div>
				<div class="header-title">
					<div class="text-button61" id="textButton9">Home</div>
					<div class="text-button62" id="textButton10">About</div>
					<div class="text-button63" id="textButton11">Tracker</div>
					<div class="text-button64">Nutrition</div>
					<div class="text-button65" id="textButton13">Workouts</div>
					<div class="tab-container-text">
						<div class="text-button66" id="textButton14">Contact</div>
					</div>
					<button class="button43" id="button">
						<div class="card-frame">Logout</div>
					</button>
				</div>
			</header>
			<main class="container-frame-card-frame-tex">
				<section class="sub-container22">
					<div class="abstract-design-vector3">
						<div class="icon-container5">
							<img
								class="icon28"
								loading="lazy"
								alt=""
								src="./public/icon.svg"
							/>
						</div>
						<div class="tabs-container-text1">
							<img
								class="abstract-design-icon6"
								alt=""
								src="./public/abstract-design.svg"
							/>

							<h1 class="heading13">Nutrition</h1>
						</div>
					</div>
					<div class="paragraph7">
						Welcome to the Nutrition section of Healthy Habits, your trusted
						source for insightful articles, tips, and expert advice on nutrition
						and wellness. Here, we strive to provide you with engaging and
						informative content that will inspire and empower you to make
						informed decisions about your health. Explore our blog to discover a
						wealth of resources that cover a wide range of topics related to
						nutrition, fitness, and overall well-being.
					</div>
				</section>
				<div class="container22">
					<div class="line11"></div>
					<div class="card4">
						<div class="card5">
							<div class="text-container-wrapper2">
								<div class="text-container7">
									<div class="heading14">Weight Loss Tips</div>
								</div>
							</div>
							<div class="line-frame-parent">
								<div class="line-frame"></div>
								<div class="image-container4">
									<img
										class="image-icon4"
										loading="lazy"
										alt=""
										src="./public/image1@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent5">
								<div class="heading-parent2">
									<div class="heading15">
										10 Effective Strategies for Sustainable Weight Loss
									</div>
									<div class="paragraph8">
										Discover proven strategies for long-term weight loss
										success. Learn how to create healthy habits, set achievable
										goals, and make sustainable lifestyle changes.
									</div>
								</div>
								<button class="button44">
									<div class="icon29">Read More</div>
								</button>
							</div>
						</div>
						<div class="card6">
							<div class="text-container-wrapper2">
								<div class="text-container7">
									<div class="heading14">Weight Loss Tips</div>
								</div>
							</div>
							<div class="line-frame-parent">
								<div class="line-frame"></div>
								<div class="image-container4">
									<img
										class="image-icon4"
										alt=""
										src="./public/image-11@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent5">
								<div class="heading-parent2">
									<div class="heading15">
										The Role of Portion Control in Weight Management
									</div>
									<div class="paragraph8">
										Learn how portion control can help you manage your weight
										effectively. Find practical tips for controlling portion
										sizes and avoiding overeating.
									</div>
								</div>
								<button class="button44">
									<div class="icon29">Read More</div>
								</button>
							</div>
						</div>
						<div class="footer-section4"></div>
					</div>
					<div class="line11"></div>
					<div class="card7">
						<div class="card8">
							<div class="text-container-wrapper2">
								<div class="text-container7">
									<div class="heading14">Weight Loss Tips</div>
								</div>
							</div>
							<div class="line-frame-parent">
								<div class="line-frame"></div>
								<div class="image-container4">
									<img
										class="image-icon4"
										alt=""
										src="./public/image-21@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent5">
								<div class="heading-parent2">
									<div class="heading15">
										Understanding Emotional Eating and How to Overcome It
									</div>
									<div class="paragraph8">
										Explore the connection between emotions and eating habits.
										Get valuable insights on how to identify emotional triggers
										and develop healthier coping mechanisms.
									</div>
								</div>
								<button class="button44">
									<div class="icon29">Read More</div>
								</button>
							</div>
						</div>
						<div class="line15"></div>
						<div class="card9">
							<div class="text-container-wrapper2">
								<div class="text-container7">
									<div class="heading14">Weight Loss Tips</div>
								</div>
							</div>
							<div class="line-frame-parent">
								<div class="line-frame"></div>
								<div class="image-container4">
									<img
										class="image-icon4"
										alt=""
										src="./public/image-31@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent5">
								<div class="heading-parent2">
									<div class="heading15">
										How to Stay Motivated on Your Weight Loss Journey
									</div>
									<div class="paragraph8">
										Find effective strategies to stay motivated and overcome
										obstacles during your weight loss journey. Get tips on
										setting realistic goals, tracking progress, and celebrating
										achievements.
									</div>
								</div>
								<button class="button44">
									<div class="icon29">Read More</div>
								</button>
							</div>
						</div>
					</div>
					<div class="line11"></div>
					<div class="card10">
						<div class="card11">
							<div class="text-container-wrapper2">
								<div class="text-container7">
									<div class="heading22">Healthy Eating</div>
								</div>
							</div>
							<div class="line-frame-parent">
								<div class="line-frame"></div>
								<div class="image-container4">
									<img
										class="image-icon4"
										alt=""
										src="./public/image-4@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent5">
								<div class="heading-parent2">
									<div class="heading15">
										The Benefits of a Plant-Based Diet for Overall Health
									</div>
									<div class="paragraph8">
										Explore the advantages of adopting a plant-based diet. Learn
										about the potential health benefits, nutrient-rich
										plant-based foods, and tips for transitioning to a
										plant-based lifestyle.
									</div>
								</div>
								<button class="button44">
									<div class="icon29">Read More</div>
								</button>
							</div>
						</div>
						<div class="card11">
							<div class="text-container-wrapper2">
								<div class="text-container7">
									<div class="heading22">Healthy Eating</div>
								</div>
							</div>
							<div class="line-frame-parent">
								<div class="line-frame"></div>
								<div class="image-container4">
									<img
										class="image-icon4"
										alt=""
										src="./public/image-5@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent5">
								<div class="heading-parent2">
									<div class="heading15">
										Understanding Macronutrients: Carbohydrates, Proteins, and
										Fats
									</div>
									<div class="paragraph8">
										Get a comprehensive overview of macronutrients and their
										role in a balanced diet. Discover the best sources of each
										macronutrient and how to incorporate them into your meals.
									</div>
								</div>
								<button class="button44">
									<div class="icon29">Read More</div>
								</button>
							</div>
						</div>
					</div>
					<div class="footer-container">
						<div class="line20"></div>
						<div class="frame-container1">
							<div class="line21"></div>
							<div class="line22"></div>
						</div>
					</div>
					<div class="line11"></div>
					<div class="card10">
						<div class="card14">
							<div class="text-container-wrapper2">
								<div class="text-container7">
									<div class="heading26">Recipes and Meal Planning</div>
								</div>
							</div>
							<div class="line-frame-parent">
								<div class="line-frame"></div>
								<div class="image-container4">
									<img
										class="image-icon4"
										alt=""
										src="./public/image-6@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent5">
								<div class="heading-parent2">
									<div class="heading15">
										Healthy and Flavorful Lunch Ideas for a Busy Lifestyle
									</div>
									<div class="paragraph8">
										Discover a variety of tasty and nutritious lunch options
										that are perfect for those with busy schedules. These
										recipes are quick to make and packed with essential
										nutrients.
									</div>
								</div>
								<button class="button44">
									<div class="icon29">Read More</div>
								</button>
							</div>
						</div>
						<div class="card15">
							<div class="text-container-wrapper2">
								<div class="text-container7">
									<div class="heading26">Recipes and Meal Planning</div>
								</div>
							</div>
							<div class="line-frame-parent">
								<div class="line-frame"></div>
								<div class="image-container4">
									<img
										class="image-icon4"
										alt=""
										src="./public/image-7@2x.png"
									/>
								</div>
							</div>
							<div class="frame-parent5">
								<div class="heading-parent2">
									<div class="heading15">
										Satisfying and Nutritious Dinner Recipes for Weight Loss
									</div>
									<div class="paragraph8">
										Find a collection of flavorful dinner recipes that are both
										satisfying and supportive of your weight loss goals. These
										recipes are designed to be healthy and delicious.
									</div>
								</div>
								<button class="button44">
									<div class="icon29">Read More</div>
								</button>
							</div>
						</div>
					</div>
				</div>
			</main>
			<footer class="footer-section5">
				<div class="container23">
					<div class="logo-wrapper">
						<div class="logo4" id="logoContainer">
							<img
								class="abstract-design-vector2"
								alt=""
								src="./public/frame-2608168.svg"
							/>

							<h2 class="healthy-habits9">Healthy Habits</h2>
						</div>
					</div>
					<div class="text-button-group">
						<div class="text-button61" id="textButton">Home</div>
						<div class="text-button62" id="textButton1">About</div>
						<div class="text-button63" id="textButton2">Tracker</div>
						<div class="text-button71" id="textButton3">Nutrition</div>
						<div class="text-button72" id="textButton4">Workouts</div>
						<div class="text-button73" id="textButton5">Contact</div>
					</div>
					<div class="sub-container23" id="subContainer">
						<div class="text21">Go To Top</div>
						<button class="button52">
							<img
								class="heroicons-miniarrow-small-up4"
								alt=""
								src="./public/heroiconsminiarrowsmallup.svg"
							/>
						</button>
					</div>
				</div>
				<div class="container24">
					<div class="sub-container24">
						<div class="button53">
							<img class="icon30" alt="" src="./public/icon-4.svg" />

							<div class="text-button74">healthyhabits@my.unt.edu</div>
						</div>
						<button class="button54">
							<img class="icon30" alt="" src="./public/icon-5.svg" />

							<div class="text-button75">+91 91813 23 2309</div>
						</button>
						<button class="button54">
							<img class="icon30" alt="" src="./public/icon-6.svg" />

							<div class="text-button76">Denton, TX</div>
						</button>
					</div>
					<div class="text-container-button">
						© 2024 Healthy Habits. All rights reserved.
					</div>
				</div>
			</footer>
		</div>

		<script>
			var textButton9 = document.getElementById("textButton9");
			if (textButton9) {
				textButton9.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton10 = document.getElementById("textButton10");
			if (textButton10) {
				textButton10.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton11 = document.getElementById("textButton11");
			if (textButton11) {
				textButton11.addEventListener("click", function (e) {
					window.location.href = "TrackerPage.php";
				});
			}

			var textButton13 = document.getElementById("textButton13");
			if (textButton13) {
				textButton13.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton14 = document.getElementById("textButton14");
			if (textButton14) {
				textButton14.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var button = document.getElementById("button");
			if (button) {
				button.addEventListener("click", function (e) {
					window.location.href = "./logout.php";
				});
			}

			var logoContainer = document.getElementById("logoContainer");
			if (logoContainer) {
				logoContainer.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton = document.getElementById("textButton");
			if (textButton) {
				textButton.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton1 = document.getElementById("textButton1");
			if (textButton1) {
				textButton1.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton2 = document.getElementById("textButton2");
			if (textButton2) {
				textButton2.addEventListener("click", function (e) {
					window.location.href = "TrackerPage.php";
				});
			}

			var textButton3 = document.getElementById("textButton3");
			if (textButton3) {
				textButton3.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton4 = document.getElementById("textButton4");
			if (textButton4) {
				textButton4.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton5 = document.getElementById("textButton5");
			if (textButton5) {
				textButton5.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					var anchor = document.querySelector("[data-scroll-to='header']");
					if (anchor) {
						anchor.scrollIntoView({ block: "start", behavior: "smooth" });
					}
				});
			}
			var frameParent = document.querySelector(".frame-child1");
			if (frameParent) {
				frameParent.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var subContainer = document.querySelector(".sub-container23");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					window.scrollTo({
						top: 0,
						behavior: "smooth",
					});
				});
			}
		</script>
	</body>
</html>
