<?php
session_start();
	
	include("connection.php");
	include("functions.php");

		$user_data = check_login($con);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1, width=device-width" />

		<link rel="stylesheet" href="./global.css" />
		<link rel="stylesheet" href="./TeamPageDesktop.css" />
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Inter:wght@700&display=swap"
		/>
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap"
		/>
	</head>
	<body>
		<div class="team-page-desktop">
			<header class="navbar5">
				<div class="navbar-child2"></div>
				<div class="footertabscontainer">
					<img
						class="healthy-habits-text"
						loading="lazy"
						alt=""
						src="./public/frame-2608168.svg"
					/>

					<h2 class="healthy-habits10">Healthy Habits</h2>
				</div>
				<div class="info-container-frame">
					<div class="text-button77" id="textButton9">Home</div>
					<div class="text-button78" id="textButton10">About</div>
					<div class="text-button79">Team</div>
					<div class="text-button80" id="textButton12">Nutrition</div>
					<div class="text-button81" id="textButton13">Workouts</div>
					<div class="design-vector-abstract">
						<div class="text-button82" id="textButton14">Contact</div>
					</div>
					<button class="button56" id="button">
						<div class="title">Logout</div>
					</button>
				</div>
			</header>
			<main class="container-parent">
				<section class="container25">
					<div class="sub-container25">
						<img
							class="abstract-design-icon7"
							alt=""
							src="./public/abstract-design.svg"
						/>

						<div class="container26">
							<img
								class="icon33"
								loading="lazy"
								alt=""
								src="./public/icon.svg"
							/>
						</div>
						<div class="text-container15">
							<h1 class="heading30">Meet Our Team of Experts</h1>
							<div class="paragraph16">
								Our team at Healthy Habits is composed of highly skilled
								professionals who are passionate about helping you achieve your
								health and wellness goals. With a diverse range of expertise in
								nutrition, coaching, and support, our team is dedicated to
								providing you with the guidance and personalized care you need.
								Get to know the experts behind our success and discover how they
								can make a positive impact on your journey to better health.
							</div>
						</div>
					</div>
					<div class="container27">
						<div class="items-container">
							<div class="card16">
								<img
									class="image-1-icon"
									loading="lazy"
									alt=""
									src="./public/image-12@2x.png"
								/>

								<div class="container28">
									<div class="text-container16">
										<div class="name">Griffith Fitzgerald</div>
										<div class="role">
											<p class="project-manager">Project Manager</p>
											<p class="evaluation-lead">Evaluation Lead</p>
										</div>
									</div>
								</div>
							</div>
							<div class="card16">
								<img
									class="image-1-icon"
									loading="lazy"
									alt=""
									src="./public/image-22@2x.png"
								/>

								<div class="container28">
									<div class="text-container16">
										<div class="name">Jacob Brekken</div>
										<div class="role">
											<p class="project-manager">Design Lead</p>
											<p class="evaluation-lead">Research Lead</p>
										</div>
									</div>
								</div>
							</div>
							<div class="card16">
								<img
									class="image-3-icon"
									loading="lazy"
									alt=""
									src="./public/image-32@2x.png"
								/>

								<div class="container28">
									<div class="text-container16">
										<div class="name">Kennedy Boynton</div>
										<div class="role2">Prototyping Lead</div>
									</div>
								</div>
							</div>
							<div class="card16">
								<img
									class="image-1-icon"
									loading="lazy"
									alt=""
									src="./public/image-22@2x.png"
								/>

								<div class="container28">
									<div class="text-container16">
										<div class="name3">Ximena Armentero</div>
										<div class="role2">Reporting Lead</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<section class="cta-section1">
					<div class="header-frame">
						<div class="c-t-a-heading">
							<img
								class="abstract-design-icon8"
								alt=""
								src="./public/abstract-design-1.svg"
							/>

							<h2 class="heading31">Join Our Team</h2>
						</div>
						<div class="paragraph17">
							We are always on the lookout for talented individuals who are
							enthusiastic about making a difference. Explore our career
							opportunities and join us in our mission to help people achieve
							their health and wellness goals.
						</div>
					</div>
					<div class="abstract-design-container">
						<img
							class="abstract-design-icon9"
							alt=""
							src="./public/abstract-design-2.svg"
						/>

						<button class="button57">
							<div class="text22">Apply Now</div>
						</button>
					</div>
				</section>
			</main>
			<footer class="footer-section6">
				<div class="container32">
					<div class="logo5" id="logoContainer">
						<img
							class="healthy-habits-text"
							alt=""
							src="./public/frame-2608168.svg"
						/>

						<h2 class="healthy-habits11">Healthy Habits</h2>
					</div>
					<div class="logo-container">
						<div class="text-button77" id="textButton">Home</div>
						<div class="text-button78" id="textButton1">About</div>
						<div class="text-button85" id="textButton2">Team</div>
						<div class="text-button86" id="textButton3">Nutrition</div>
						<div class="text-button87" id="textButton4">Workouts</div>
						<div class="text-button88" id="textButton5">Contact</div>
					</div>
					<div class="sub-container26" id="subContainer">
						<div class="footer-text">Go To Top</div>
						<button class="button58">
							<img
								class="heroicons-miniarrow-small-up5"
								alt=""
								src="./public/heroiconsminiarrowsmallup.svg"
							/>
						</button>
					</div>
				</div>
				<div class="container33">
					<div class="sub-container27">
						<div class="button59">
							<img class="icon34" alt="" src="./public/icon-4.svg" />

							<div class="text-button89">healthyhabits@my.unt.edu</div>
						</div>
						<button class="button60">
							<img class="icon34" alt="" src="./public/icon-5.svg" />

							<div class="text-button90">+91 91813 23 2309</div>
						</button>
						<button class="button60">
							<img class="icon34" alt="" src="./public/icon-6.svg" />

							<div class="text-button91">Denton, TX</div>
						</button>
					</div>
					<div class="name-role">
						© 2024 Healthy Habits. All rights reserved.
					</div>
				</div>
			</footer>
		</div>

		<script>
			var textButton9 = document.getElementById("textButton9");
			if (textButton9) {
				textButton9.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton10 = document.getElementById("textButton10");
			if (textButton10) {
				textButton10.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton12 = document.getElementById("textButton12");
			if (textButton12) {
				textButton12.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton13 = document.getElementById("textButton13");
			if (textButton13) {
				textButton13.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton14 = document.getElementById("textButton14");
			if (textButton14) {
				textButton14.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var button = document.getElementById("button");
			if (button) {
				button.addEventListener("click", function (e) {
					window.location.href = "./logout.php";
				});
			}

			var logoContainer = document.getElementById("logoContainer");
			if (logoContainer) {
				logoContainer.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton = document.getElementById("textButton");
			if (textButton) {
				textButton.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton1 = document.getElementById("textButton1");
			if (textButton1) {
				textButton1.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton2 = document.getElementById("textButton2");
			if (textButton2) {
				textButton2.addEventListener("click", function (e) {
					window.location.href = "./TeamPageDesktop.php";
				});
			}

			var textButton3 = document.getElementById("textButton3");
			if (textButton3) {
				textButton3.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton4 = document.getElementById("textButton4");
			if (textButton4) {
				textButton4.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton5 = document.getElementById("textButton5");
			if (textButton5) {
				textButton5.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					var anchor = document.querySelector("[data-scroll-to='header']");
					if (anchor) {
						anchor.scrollIntoView({ block: "start", behavior: "smooth" });
					}
				});
			}
			var frameParent = document.querySelector(".footertabscontainer");
			if (frameParent) {
				frameParent.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var subContainer = document.querySelector(".sub-container26");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					window.scrollTo({
						top: 0,
						behavior: "smooth",
					});
				});
			}
		</script>
	</body>
</html>
