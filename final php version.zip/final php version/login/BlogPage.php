<?php

?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1, width=device-width" />
		<title>Blog Page</title>
		<link rel="stylesheet" href="./global.css" />
		<link rel="stylesheet" href="./BlogPage.css" />
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Inter:wght@700&display=swap"
		/>
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap"
		/>
	</head>
	<body>
		<div class="login-page-desktop">
			<header class="navbar7">
				<div class="navbar-child5"></div>
				<div class="frame-parent12">
					<img
						class="frame-inner"
						loading="lazy"
						alt=""
						src="./public/frame-2608168.svg"
					/>

					<h2 class="healthy-habits14">Healthy Habits</h2>
				</div>
				<div class="text-button-frame1">
					<div class="text-button107" id="textButton9">Home</div>
					<div class="text-button108" id="textButton10">About</div>
					<div class="text-button109" id="textButton11">Tracker</div>
					<div class="text-button110" id="textButton12">Nutrition</div>
					<div class="text-button111" id="textButton13">Workouts</div>
					<div class="text-button-wrapper1">
						<div class="text-button112" id="textButton14">Contact</div>
					</div>
					<button class="button68" id="loginButton">
						<div class="form-elements-sub">Logout</div>
					</button>
				</div>
			</header>
			<main class="label7">
				<section class="sub-container41">
					<div class="text-container42">
						<div class="abstract-design-vector3">
							<img
								class="abstract-design-icon11"
								alt=""
								src="./public/abstract-design.svg"
							/>
						</div>
					</div>
					<h1 class="heading62">Blog Title</h1>
					<img class="banner.png" src="public/banner.png" alt="" />
					<div class="blog-content-1">
						<h1 class="paragraph">Lorem ipsum</h1>
						Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
						eiusmod tempor incididunt ut labore et dolore magna aliqua. Vitae
						semper quis lectus nulla at. Tristique nulla aliquet enim tortor at.
						Amet massa vitae tortor condimentum. Egestas fringilla phasellus
						faucibus scelerisque eleifend donec pretium vulputate. Fermentum dui
						faucibus in ornare quam. Turpis massa sed elementum tempus egestas
						sed. Vitae ultricies leo integer malesuada nunc vel risus. Neque
						volutpat ac tincidunt vitae semper. Pharetra pharetra massa massa
						ultricies mi quis. Nunc mi ipsum faucibus vitae aliquet nec
						ullamcorper sit amet. Est ultricies integer quis auctor elit sed
						vulputate mi sit. Dignissim convallis aenean et tortor at risus
						viverra adipiscing. Enim ut tellus elementum sagittis vitae et leo.
						Faucibus purus in massa tempor nec. Sed felis eget velit aliquet
						sagittis id consectetur purus ut. Posuere urna nec tincidunt
						praesent. Molestie a iaculis at erat pellentesque adipiscing commodo
						elit.

						<div class="blog-content-2">
							Nulla posuere sollicitudin aliquam ultrices. Arcu cursus euismod
							quis viverra nibh cras pulvinar. Elit scelerisque mauris
							pellentesque pulvinar pellentesque habitant morbi tristique. Purus
							sit amet luctus venenatis lectus magna fringilla urna porttitor.
							Et ligula ullamcorper malesuada proin libero. Blandit volutpat
							maecenas volutpat blandit aliquam etiam erat velit scelerisque.
							Convallis a cras semper auctor. Ac tortor vitae purus faucibus.
							Vel eros donec ac odio. Quis ipsum suspendisse ultrices gravida
							dictum fusce ut placerat. A iaculis at erat pellentesque
							adipiscing commodo elit. In dictum non consectetur a erat. Enim
							lobortis scelerisque fermentum dui faucibus. Mauris augue neque
							gravida in fermentum. Consequat id porta nibh venenatis cras sed
							felis. Amet mauris commodo quis imperdiet massa tincidunt nunc
							pulvinar. Magna ac placerat vestibulum lectus mauris ultrices eros
							in cursus.
						</div>
						<h1 class="paragraph">Lorem ipsum</h1>
						<div class="blog-content-3">
							Integer feugiat scelerisque varius morbi enim nunc. Massa enim nec
							dui nunc. Sagittis aliquam malesuada bibendum arcu vitae. Ut etiam
							sit amet nisl purus in mollis nunc. Sed libero enim sed faucibus
							turpis in. Suspendisse interdum consectetur libero id faucibus
							nisl tincidunt. Maecenas pharetra convallis posuere morbi leo.
							Accumsan sit amet nulla facilisi morbi tempus iaculis. Magna eget
							est lorem ipsum. Sed libero enim sed faucibus. Amet consectetur
							adipiscing elit pellentesque. Cras semper auctor neque vitae
							tempus. Dolor purus non enim praesent elementum facilisis leo vel.
							Duis ultricies lacus sed turpis tincidunt id. Malesuada nunc vel
							risus commodo viverra.
						</div>
						<div class="blog-content-4">
							Aliquam sem fringilla ut morbi tincidunt augue. Ut pharetra sit
							amet aliquam id diam maecenas. Id interdum velit laoreet id donec
							ultrices tincidunt arcu. Elit ut aliquam purus sit amet. Dolor
							morbi non arcu risus quis varius quam. Aliquam faucibus purus in
							massa tempor. Vel orci porta non pulvinar neque laoreet
							suspendisse interdum. Consequat interdum varius sit amet mattis.
							Adipiscing tristique risus nec feugiat in fermentum posuere urna.
							Vulputate odio ut enim blandit volutpat maecenas volutpat blandit.
							Turpis egestas pretium aenean pharetra magna ac. Quis blandit
							turpis cursus in hac habitasse. Nisl nunc mi ipsum faucibus vitae
							aliquet nec ullamcorper sit. Auctor urna nunc id cursus metus
							aliquam eleifend. Lectus quam id leo in. Nullam non nisi est sit
							amet facilisis magna. Nulla malesuada pellentesque elit eget
							gravida cum sociis natoque penatibus. Tortor vitae purus faucibus
							ornare suspendisse sed nisi.
						</div>
						<h1 class="paragraph">Lorem ipsum</h1>
						<div class="blog-content-5">
							Tortor pretium viverra suspendisse potenti nullam. Duis at
							consectetur lorem donec. At elementum eu facilisis sed odio. Nisl
							nunc mi ipsum faucibus vitae aliquet. Aliquam sem fringilla ut
							morbi tincidunt. Tincidunt lobortis feugiat vivamus at augue.
							Purus gravida quis blandit turpis. Dictum varius duis at
							consectetur lorem donec massa sapien faucibus. Odio pellentesque
							diam volutpat commodo sed. Feugiat pretium nibh ipsum consequat
							nisl vel pretium lectus. Et magnis dis parturient montes nascetur
							ridiculus. Bibendum enim facilisis gravida neque convallis.
						</div>
					</div>
				</section>
				<section class="comment-section">
					<div class="head"><h1>Post a Comment</h1></div>
					<div><span id="comment">0</span> Comments</div>
					<div class="label8"><p>We are happy to hear from you</p></div>
					<div class="comments"></div>
					<div class="commentbox"></div>
					<img src="public/user1.jpg" alt="" />
					<h2>Comment as:</h2>
					<input class="user" value="Anonymous" type="text" />
					<div class="commentinput">
						<input
							class="usercomment"
							placeholder="Enter comment"
							type="text"
						/>
						<div class="buttons">
							<button type="submit" disabled id="publish">Publish</button>
							<div class="notify">
								<input type="checkbox" class="notifyinput" />
								<span>Notify me</span>
							</div>
						</div>
					</div>
					<p class="policy">
						This site is protected by reCAPTCHA and the Google
						<a href="">privacy policy</a> and <a href="">Terms of Service</a>
					</p>
				</section>
			</main>
			<footer class="footer-section8">
				<div class="container91">
					<div class="logo7" id="logoContainer">
						<img class="logo-item" alt="" src="./public/frame-2608168.svg" />

						<h2 class="healthy-habits15">Healthy Habits</h2>
					</div>
					<div class="text-footer-button">
						<div class="text-button113" id="textButton">Home</div>
						<div class="text-button114" id="textButton1">About</div>
						<div class="text-button115" id="textButton2">Tracker</div>
						<div class="text-button116" id="textButton3">Nutrition</div>
						<div class="text-button117" id="textButton4">Workouts</div>
						<div class="text-button118" id="textButton5">Contact</div>
					</div>
					<div class="sub-container44" id="subContainer">
						<div class="buttons-container6">Go To Top</div>
						<button class="button73">
							<img
								class="heroicons-miniarrow-small-up7"
								alt=""
								src="./public/heroiconsminiarrowsmallup.svg"
							/>
						</button>
					</div>
				</div>
				<div class="container92">
					<div class="sub-container45">
						<div class="button74">
							<img class="icon61" alt="" src="./public/icon-4.svg" />

							<div class="text-button119">healthyhabits@gmail.com</div>
						</div>
						<button class="button75">
							<img class="icon62" alt="" src="./public/icon-5.svg" />

							<div class="text-button120">+91 91813 23 2309</div>
						</button>
						<button class="button76">
							<img class="icon63" alt="" src="./public/icon-6.svg" />

							<div class="text-button121">Denton, TX</div>
						</button>
					</div>
					<div class="container93">
						© 2024 Healthy Habits. All rights reserved.
					</div>
				</div>
			</footer>
		</div>

		<script src="script.js"></script>
		<script>
			var textButton9 = document.getElementById("textButton9");
			if (textButton9) {
				textButton9.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton10 = document.getElementById("textButton10");
			if (textButton10) {
				textButton10.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton12 = document.getElementById("textButton12");
			if (textButton12) {
				textButton12.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton13 = document.getElementById("textButton13");
			if (textButton13) {
				textButton13.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton14 = document.getElementById("textButton14");
			if (textButton14) {
				textButton14.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var frameContainer = document.getElementById("frameContainer");
			if (frameContainer) {
				frameContainer.addEventListener("click", function (e) {
					window.location.href = "./SignUpPageDesktop.php";
				});
			}

			var logoContainer = document.getElementById("logoContainer");
			if (logoContainer) {
				logoContainer.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton = document.getElementById("textButton");
			if (textButton) {
				textButton.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton1 = document.getElementById("textButton1");
			if (textButton1) {
				textButton1.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton2 = document.getElementById("textButton2");
			if (textButton2) {
				textButton2.addEventListener("click", function (e) {
					window.location.href = "TeamPageDesktop.php";
				});
			}

			var textButton3 = document.getElementById("textButton3");
			if (textButton3) {
				textButton3.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton4 = document.getElementById("textButton4");
			if (textButton4) {
				textButton4.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton5 = document.getElementById("textButton5");
			if (textButton5) {
				textButton5.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					var anchor = document.querySelector("[data-scroll-to='header']");
					if (anchor) {
						anchor.scrollIntoView({ block: "start", behavior: "smooth" });
					}
				});
			}
			var loginButton = document.getElementById("loginButton");
			if (loginButton) {
				loginButton.addEventListener("click", function (e) {
					window.location.href = "./logout.php";
				});
			}
			var frameParent = document.querySelector(".frame-parent12");
			if (frameParent) {
				frameParent.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}
			var subContainer = document.querySelector(".sub-container44");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					window.scrollTo({
						top: 0,
						behavior: "smooth",
					});
				});
			}
		</script>
		<script>
			"use strict";

			// Function to get comments from local storage or return an empty array
			function getCommentsFromLocalStorage() {
				const comments = localStorage.getItem("comments");
				return comments ? JSON.parse(comments) : [];
			}

			// Function to save comments to local storage
			function saveCommentsToLocalStorage(comments) {
				localStorage.setItem("comments", JSON.stringify(comments));
			}

			const userId = {
				name: null,
				identity: null,
				image: null,
				message: null,
				date: null,
			};

			const userComment = document.querySelector(".usercomment");
			const publishBtn = document.querySelector("#publish");
			const comments = document.querySelector(".comments");
			const userName = document.querySelector(".user");

			userComment.addEventListener("input", (e) => {
				if (!userComment.value) {
					publishBtn.setAttribute("disabled", "disabled");
					publishBtn.classList.remove("abled");
				} else {
					publishBtn.removeAttribute("disabled");
					publishBtn.classList.add("abled");
				}
			});

			function addPost() {
				console.log("The button works!");
				if (!userComment.value) return;
				userId.name = userName.value;
				if (userId.name == "Anonymous") {
					userId.indentity = false;
					userId.image = "public/anonymous.png";
				} else {
					userId.indentity = true;
					userId.image = "user.png";
				}

				userId.message = userComment.value;
				userId.date = new Date().toLocaleString();
				let published = `<div class="parents">
   <img src="${userId.image}">
   <div>
       <h1>${userId.name}</h1>
       <p>${userId.message}</p>
       <div class="engagements"><img src="public/like.png" id="like"><img src="public/share.png" alt=""></div>
       <span class="date">${userId.date}</span>
   </div>    
</div>`;

				comments.innerHTML += published;
				userComment.value = "";
				publishBtn.classList.remove("abled");

				let commentsNum = document.querySelectorAll(".parents").length;
				document.getElementById("comment").textContent = commentsNum;

				// Save the comments to local storage
				const allComments = getCommentsFromLocalStorage();
				allComments.push(userId);
				saveCommentsToLocalStorage(allComments);
			}

			publishBtn.addEventListener("click", addPost);

			// Retrieve comments from local storage on page load
			window.addEventListener("DOMContentLoaded", function () {
				const allComments = getCommentsFromLocalStorage();
				allComments.forEach(function (comment) {
					let published = `<div class="parents">
            <img src="${comment.image}">
            <div>
                  <h1>${comment.name}</h1>
                  <p>${comment.message}</p>
                  <div class="engagements"><img src="public/like.png" id="like"><img src="public/share.png" alt=""></div>
                  <span class="date">${comment.date}</span>
            </div>    
      </div>`;
					comments.innerHTML += published;
				});
			});
		</script>
	</body>
</html>
