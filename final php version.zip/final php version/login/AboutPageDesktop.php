<?php
session_start();
	
	include("connection.php");
	include("functions.php");

		$user_data = check_login($con);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1, width=device-width" />

		<link rel="stylesheet" href="./global.css" />
		<link rel="stylesheet" href="./AboutPageDesktop.css" />
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Inter:wght@700&display=swap"
		/>
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap"
		/>
	</head>
	<body>
		<div class="about-page-desktop">
			<header class="header" data-scroll-to="header">
				<div class="navbar6">
					<div class="navbar-child3"></div>
					<div class="healthy-habits-text2">
						<img
							class="healthy-habits-text-child"
							loading="lazy"
							alt=""
							src="./public/frame-2608168.svg"
						/>

						<h2 class="healthy-habits12">Healthy Habits</h2>
					</div>
					<div class="text-button-parent1">
						<div class="text-button92" id="textButton9">Home</div>
						<div class="text-button93">About</div>
						<div class="text-button94" id="textButton11">Tracker</div>
						<div class="text-button95" id="textButton12">Nutrition</div>
						<div class="text-button96" id="textButton13">Workouts</div>
						<div class="text-button-wrapper1">
							<div class="text-button97" id="textButton14">Contact</div>
						</div>
						<button class="button62" id="button">
							<div class="text23">Logout</div>
						</button>
					</div>
				</div>
			</header>
			<main class="frame-image">
				<section class="image-wrapper">
					<img
						class="image-icon12"
						loading="lazy"
						alt=""
						src="./public/image2.svg"
					/>
				</section>
				<section class="paragraph18">
					<div class="text-container20">
						<h1 class="heading32">Welcome to Healthy Habits</h1>
						<div class="paragraph19">
							<p class="your-trusted-source">
								Your trusted source for personalized nutrition coaching. Our
								mission is to help you achieve your weight loss and health goals
								through tailored nutrition plans and expert guidance. We
								understand that every individual is unique, and that's why we
								believe in providing personalized solutions that fit your
								lifestyle and preferences.
							</p>
							<p class="your-trusted-source">
								With our team of qualified nutritionists and dietitians, we are
								dedicated to empowering you with the knowledge and tools you
								need to make lasting changes. Whether you want to shed those
								extra pounds, improve your overall well-being, or develop a
								healthier relationship with food, we are here to support you
								every step of the way.
							</p>
							<p class="your-trusted-source">
								At Healthy Habits, we believe that healthy eating should be
								enjoyable and sustainable. We emphasize the importance of
								balanced nutrition, focusing on whole foods and mindful eating
								practices. Our approach is rooted in scientific research and
								evidence-based strategies, ensuring that you receive the most
								up-to-date and accurate information.
							</p>
							<p class="your-trusted-source">
								Join our community of individuals committed to transforming
								their lives through nutrition. Take control of your health,
								boost your energy levels, and discover the joy of nourishing
								your body with wholesome foods. We are here to guide you towards
								a healthier, happier you.
							</p>
						</div>
					</div>
				</section>
				<section class="items-container1">
					<div class="heading-parent10">
						<h1 class="heading33">Our Story</h1>
						<div class="paragraph20">
							Welcome to Healthy Habits, your partner in achieving optimal
							health through personalized nutrition coaching. Our certified
							nutritionists are here to guide you on your weight loss journey.
						</div>
					</div>
					<div class="items-container2">
						<div class="container34">
							<img class="image-icon13" alt="" src="./public/image-13@2x.png" />

							<div class="shape"></div>
							<div class="text-container21">
								<div class="paragraph21">
									<div class="container35">
										<h3 class="heading34">Inspiring Transformations Story</h3>
									</div>
								</div>
								<div class="paragraph22">
									Healthy Habits continues to empower individuals to transform
									their lives through personalized nutrition coaching. With an
									expanding client base and a growing team of experts, we remain
									committed to our goal of helping people lose weight, improve
									their health, and lead happier, more fulfilling lives. Our
									journey of inspiring transformations continues, one client at
									a time.
								</div>
								<div class="date">July 1, 2025</div>
							</div>
						</div>
						<div class="container36">
							<div class="text-container22">
								<div class="paragraph-container">
									<div class="container35">
										<h3 class="heading35">Recognition and Accolades Story</h3>
									</div>
								</div>
								<div class="paragraph23">
									Healthy Habits received industry recognition for its
									excellence in personalized nutrition coaching. Our innovative
									approach and dedication to client success earned us accolades
									and solidified our position as a leading provider in the
									field.
								</div>
								<div class="date">March 10, 2023</div>
							</div>
							<div class="shape"></div>
							<img class="image-icon14" alt="" src="./public/image-23@2x.png" />
						</div>
						<div class="container34">
							<img class="image-icon13" alt="" src="./public/image-33@2x.png" />

							<div class="shape"></div>
							<div class="text-container23">
								<div class="container-wrapper">
									<button class="container39">
										<div class="heading36">Continued Growth Story</div>
									</button>
								</div>
								<div class="paragraph23">
									Healthy Habits celebrated serving over 5,000 clients, a
									testament to our commitment to helping individuals achieve
									their health and weight loss goals. This milestone highlighted
									the positive impact we have made on the lives of thousands of
									people.
								</div>
								<div class="date">November 2, 2021</div>
							</div>
						</div>
						<div class="container36">
							<div class="text-container23">
								<div class="paragraph-container">
									<div class="container35">
										<h3 class="heading37">Collaborating for Success Story</h3>
									</div>
								</div>
								<div class="paragraph23">
									Healthy Habits established partnerships with renowned health
									professionals, including nutritionists, dietitians, and
									wellness experts. These collaborations allowed us to
									incorporate diverse perspectives and expertise, ensuring the
									highest level of guidance for our clients.
								</div>
								<div class="date">July 15, 2019</div>
							</div>
							<div class="shape"></div>
							<img class="image-icon14" alt="" src="./public/image-41@2x.png" />
						</div>
						<div class="container34">
							<img class="image-icon13" alt="" src="./public/image-51@2x.png" />

							<div class="shape"></div>
							<div class="text-container23">
								<div class="container-frame">
									<div class="container43">
										<h3 class="heading38">Enhanced Support Story</h3>
									</div>
								</div>
								<div class="paragraph23">
									In response to the growing demand for personalized nutrition
									coaching, Healthy Habits expanded its team of qualified
									nutritionists and dietitians. This milestone enabled us to
									provide even more individualized care and support to our
									clients.
								</div>
								<div class="date">April 1, 2018</div>
							</div>
						</div>
						<div class="container36">
							<div class="text-container23">
								<div class="paragraph-container">
									<div class="container35">
										<h3 class="heading39">Innovating for Clients Story</h3>
									</div>
								</div>
								<div class="paragraph23">
									Healthy Habits introduced a mobile app, revolutionizing the
									way clients engage with their personalized nutrition plans.
									The app allowed for easy tracking of progress, access to
									resources, and seamless communication with their dedicated
									nutrition coaches.
								</div>
								<div class="date">January 20, 2017</div>
							</div>
							<div class="shape"></div>
							<img class="image-icon14" alt="" src="./public/image-61@2x.png" />
						</div>
						<div class="container34">
							<img class="image-icon13" alt="" src="./public/image-71@2x.png" />

							<div class="shape"></div>
							<div class="text-container23">
								<div class="paragraph21">
									<div class="container35">
										<h3 class="heading40">Celebrating Success Stories</h3>
									</div>
								</div>
								<div class="paragraph23">
									Healthy Habits celebrated its 500th client success story.
									These stories showcased the positive impact of personalized
									nutrition coaching on individuals' lives, further motivating
									our team to continue providing exceptional services.
								</div>
								<div class="date">September 5, 2015</div>
							</div>
						</div>
						<div class="container36">
							<div class="text-container23">
								<div class="container-wrapper3">
									<div class="container43">
										<h3 class="heading41">Expanding Reach Story</h3>
									</div>
								</div>
								<div class="paragraph23">
									Healthy Habits expanded its services by launching an online
									platform, allowing individuals from all over the world to
									access personalized nutrition plans and expert guidance. This
									milestone brought convenience and accessibility to our growing
									client base.
								</div>
								<div class="date">June 10, 2014</div>
							</div>
							<div class="shape"></div>
							<img class="image-icon14" alt="" src="./public/image-8@2x.png" />
						</div>
						<div class="container34">
							<img class="image-icon13" alt="" src="./public/image-9@2x.png" />

							<div class="shape"></div>
							<div class="text-container21">
								<div class="container-wrapper4">
									<button class="container51">
										<div class="heading42">Research and Expertise Story</div>
									</button>
								</div>
								<div class="paragraph22">
									After extensive research and collaborating with nutrition
									experts, Sarah Mitchell and her team developed a comprehensive
									program rooted in scientific knowledge and evidence-based
									strategies. This milestone marked the establishment of Healthy
									Habits as a trusted source of personalized nutrition coaching.
								</div>
								<div class="date">March 15, 2012</div>
							</div>
						</div>
						<div class="container36">
							<div class="text-container21">
								<div class="container-wrapper3">
									<div class="container43">
										<h3 class="heading43">The Inception Story</h3>
									</div>
								</div>
								<div class="paragraph22">
									On this day, Healthy Habits was born with the vision of
									helping individuals achieve their weight loss and health goals
									through personalized nutrition coaching. The founder, Sarah
									Mitchell, recognized the need for a sustainable and effective
									approach to healthy living, and thus began the journey of
									Healthy Habits.
								</div>
								<div class="date">January 1, 2010</div>
							</div>
							<div class="shape"></div>
							<img class="image-icon14" alt="" src="./public/image-10@2x.png" />
						</div>
					</div>
				</section>
				<section class="shape10">
					<div class="container54">
						<div class="text-container31">
							<h1 class="heading44">Company Achievements</h1>
							<div class="paragraph32">
								At Healthy Habits, we take pride in our accomplishments and the
								positive impact we have made on the lives of our clients. Here
								are some of our notable achievements
							</div>
						</div>
						<div class="sub-container28">
							<div class="container55">
								<div class="card20">
									<div class="container56">
										<button class="icon-container6">
											<img class="icon37" alt="" src="./public/icon.svg" />
										</button>
										<div class="heading45">10,000+ Transformations</div>
									</div>
									<div class="paragraph33">
										Our personalized nutrition plans have helped thousands of
										individuals reach their weight loss goals and maintain a
										healthy lifestyle.
									</div>
								</div>
								<div class="card21">
									<div class="container56">
										<button class="icon-container6">
											<img class="icon38" alt="" src="./public/icon-12.svg" />
										</button>
										<div class="heading46">Recognition for Excellence</div>
									</div>
									<div class="paragraph34">
										Healthy Habits has been recognized as a leading provider of
										personalized nutrition coaching, receiving accolades for our
										innovative approach and commitment to client success.
									</div>
								</div>
							</div>
							<div class="container55">
								<div class="card21">
									<div class="container56">
										<button class="icon-container6">
											<img class="icon37" alt="" src="./public/icon-22.svg" />
										</button>
										<div class="heading47">Positive Client Reviews</div>
									</div>
									<div class="paragraph34">
										We have received numerous testimonials from satisfied
										clients who have experienced significant improvements in
										their health, weight, and overall well-being through our
										coaching program.
									</div>
								</div>
								<div class="card21">
									<div class="container56">
										<div class="icon-container9">
											<img class="icon37" alt="" src="./public/icon-32.svg" />
										</div>
										<div class="heading48">
											Collaborate With Top Health Experts.
										</div>
									</div>
									<div class="paragraph34">
										Healthy Habits has established partnerships with respected
										nutritionists, dietitians, and health experts to ensure that
										our clients receive the highest quality guidance and
										support.
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<section class="cta-section2">
					<div class="abstract-design">
						<div class="abstract-design-parent1">
							<img
								class="abstract-design-icon10"
								loading="lazy"
								alt=""
								src="./public/abstract-design.svg"
							/>

							<h2 class="heading49">We Are Proud of Our Achievements</h2>
						</div>
						<div class="paragraph37">
							But our ultimate satisfaction comes from seeing our clients
							achieve their goals and live healthier, happier lives. Join
							Healthy Habits today and embark on your own transformative journey
							towards optimal health and well-being.
						</div>
					</div>
					<div class="c-t-a-section-frame">
						<img
							class="abstract-design-icon11"
							alt=""
							src="./public/abstract-design-2.svg"
						/>

						<button class="button63">
							<div class="button-text-button">Book a Demo</div>
						</button>
					</div>
				</section>
			</main>
			<footer class="footer-section7">
				<div class="container61">
					<div class="logo-frame">
						<div class="logo6" id="logoContainer">
							<img
								class="healthy-habits-text-child"
								alt=""
								src="./public/frame-2608168.svg"
							/>

							<h2 class="healthy-habits13">Healthy Habits</h2>
						</div>
					</div>
					<div class="frame-text-button">
						<div class="text-button98" id="textButton">Home</div>
						<div class="text-button99" id="textButton1">About</div>
						<div class="text-button94" id="textButton2">Tracker</div>
						<div class="text-button101" id="textButton3">Nutrition</div>
						<div class="text-button102" id="textButton4">Workouts</div>
						<div class="text-button103" id="textButton5">Contact</div>
					</div>
					<div class="sub-container29" id="subContainer">
						<div class="paragraph38">Go To Top</div>
						<button class="button64">
							<img
								class="heroicons-miniarrow-small-up6"
								alt=""
								src="./public/heroiconsminiarrowsmallup.svg"
							/>
						</button>
					</div>
				</div>
				<div class="container62">
					<div class="sub-container30">
						<div class="button65">
							<img class="icon41" alt="" src="./public/icon-4.svg" />

							<div class="text-button104">healthyhabits@my.unt.edu</div>
						</div>
						<button class="button66">
							<img class="icon41" alt="" src="./public/icon-5.svg" />

							<div class="text-button105">+91 91813 23 2309</div>
						</button>
						<button class="button66">
							<img class="icon41" alt="" src="./public/icon-6.svg" />

							<div class="text-button106">Denton, TX</div>
						</button>
					</div>
					<div class="sub-container31">
						© 2024 Healthy Habits. All rights reserved.
					</div>
				</div>
			</footer>
		</div>

		<script>
			var textButton9 = document.getElementById("textButton9");
			if (textButton9) {
				textButton9.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton11 = document.getElementById("textButton11");
			if (textButton11) {
				textButton11.addEventListener("click", function (e) {
					window.location.href = "./TrackerPage.php";
				});
			}

			var textButton12 = document.getElementById("textButton12");
			if (textButton12) {
				textButton12.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton13 = document.getElementById("textButton13");
			if (textButton13) {
				textButton13.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton14 = document.getElementById("textButton14");
			if (textButton14) {
				textButton14.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var button = document.getElementById("button");
			if (button) {
				button.addEventListener("click", function (e) {
					window.location.href = "./logout.php";
				});
			}

			var logoContainer = document.getElementById("logoContainer");
			if (logoContainer) {
				logoContainer.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton = document.getElementById("textButton");
			if (textButton) {
				textButton.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton1 = document.getElementById("textButton1");
			if (textButton1) {
				textButton1.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton2 = document.getElementById("textButton2");
			if (textButton2) {
				textButton2.addEventListener("click", function (e) {
					window.location.href = "./TeamPageDesktop.php";
				});
			}

			var textButton3 = document.getElementById("textButton3");
			if (textButton3) {
				textButton3.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton4 = document.getElementById("textButton4");
			if (textButton4) {
				textButton4.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton5 = document.getElementById("textButton5");
			if (textButton5) {
				textButton5.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					var anchor = document.querySelector("[data-scroll-to='header']");
					if (anchor) {
						anchor.scrollIntoView({ block: "start", behavior: "smooth" });
					}
				});
			}
			var frameParent = document.querySelector(".healthy-habits-text2");
			if (frameParent) {
				frameParent.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}
		</script>
	</body>
</html>
