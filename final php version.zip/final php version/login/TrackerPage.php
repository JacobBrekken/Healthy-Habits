<?php
session_start();
	
	include("connection.php");
	include("functions.php");

		$user_data = check_login($con);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1, width=device-width" />
		<title>Login Page</title>
		<link rel="stylesheet" href="./global.css" />
		<link rel="stylesheet" href="./TrackerPage.css" />
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Inter:wght@700&display=swap"
		/>
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap"
		/>
	</head>
	<body>
		<div class="login-page-desktop">
			<header class="navbar7">
				<div class="navbar-child5"></div>
				<div class="frame-parent12">
					<img
						class="frame-inner"
						loading="lazy"
						alt=""
						src="./public/frame-2608168.svg"
					/>

					<h2 class="healthy-habits14">Healthy Habits</h2>
				</div>
				<div class="text-button-frame1">
					<div class="text-button107" id="textButton9">Home</div>
					<div class="text-button108" id="textButton10">About</div>
					<div class="text-button109" id="textButton11">Tracker</div>
					<div class="text-button110" id="textButton12">Nutrition</div>
					<div class="text-button111" id="textButton13">Workouts</div>
					<div class="text-button-wrapper1">
						<div class="text-button112" id="textButton14">Contact</div>
					</div>
					<button class="button68" id="loginButton">
						<div class="form-elements-sub">Logout</div>
					</button>
				</div>
			</header>
			<main class="label7">
				<section class="sub-container41">
					<div class="text-container42">
						<div class="abstract-design-vector3">
							<img
								class="abstract-design-icon11"
								alt=""
								src="./public/abstract-design.svg"
							/>
						</div>
					</div>
					<h1 class="heading62">Calorie Tracker</h1>
					<div class="skill">
						<div class="outer">
							<div class="inner">
								<div class="number"></div>
							</div>
						</div>
					</div>
					<svg
						xmlns="http://www.w3.org/2000/svg"
						version="1.1"
						width="360px"
						height="360px"
					>
						<defs>
							<linearGradient id="GradientColor">
								<stop offset="0%" stop-color="#335933" />
								<stop offset="100%" stop-color="#cbea7b" />
							</linearGradient>
						</defs>
						<circle
							cx="180"
							cy="180"
							r="160"
							stroke-linecap="round"
							transform="rotate(-90)"
							transform-origin="center"
						/>
					</svg>
				</section>
				<div class="container89">
					<div class="form-elements2">
						<div class="sub-container42">
							<div class="label8">Calories Consumed</div>
							<div class="input-field7">
								<input
									class="input"
									placeholder="Enter your Calories Consumed"
									type="number"
								/>
							</div>
						</div>
						<div class="container90">
							<div class="label9">Daily Calories</div>
							<div class="input-field8">
								<input
									class="maxInput"
									placeholder="Enter your Daily Calories"
									type="number"
								/>
							</div>
						</div>
					</div>
				</div>
			</main>
			<footer class="footer-section8">
				<div class="container91">
					<div class="logo7" id="logoContainer">
						<img class="logo-item" alt="" src="./public/frame-2608168.svg" />

						<h2 class="healthy-habits15">Healthy Habits</h2>
					</div>
					<div class="text-footer-button">
						<div class="text-button113" id="textButton">Home</div>
						<div class="text-button114" id="textButton1">About</div>
						<div class="text-button115" id="textButton2">Tracker</div>
						<div class="text-button116" id="textButton3">Nutrition</div>
						<div class="text-button117" id="textButton4">Workouts</div>
						<div class="text-button118" id="textButton5">Contact</div>
					</div>
					<div class="sub-container44" id="subContainer">
						<div class="buttons-container6">Go To Top</div>
						<button class="button73">
							<img
								class="heroicons-miniarrow-small-up7"
								alt=""
								src="./public/heroiconsminiarrowsmallup.svg"
							/>
						</button>
					</div>
				</div>
				<div class="container92">
					<div class="sub-container45">
						<div class="button74">
							<img class="icon61" alt="" src="./public/icon-4.svg" />

							<div class="text-button119">healthyhabits@gmail.com</div>
						</div>
						<button class="button75">
							<img class="icon62" alt="" src="./public/icon-5.svg" />

							<div class="text-button120">+91 91813 23 2309</div>
						</button>
						<button class="button76">
							<img class="icon63" alt="" src="./public/icon-6.svg" />

							<div class="text-button121">Denton, TX</div>
						</button>
					</div>
					<div class="container93">
						© 2024 Healthy Habits. All rights reserved.
					</div>
				</div>
			</footer>
		</div>

		<script src="script.js"></script>
		<script>
			var textButton9 = document.getElementById("textButton9");
			if (textButton9) {
				textButton9.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton10 = document.getElementById("textButton10");
			if (textButton10) {
				textButton10.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton12 = document.getElementById("textButton12");
			if (textButton12) {
				textButton12.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton13 = document.getElementById("textButton13");
			if (textButton13) {
				textButton13.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton14 = document.getElementById("textButton14");
			if (textButton14) {
				textButton14.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var frameContainer = document.getElementById("frameContainer");
			if (frameContainer) {
				frameContainer.addEventListener("click", function (e) {
					window.location.href = "./SignUpPageDesktop.php";
				});
			}

			var logoContainer = document.getElementById("logoContainer");
			if (logoContainer) {
				logoContainer.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton = document.getElementById("textButton");
			if (textButton) {
				textButton.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton1 = document.getElementById("textButton1");
			if (textButton1) {
				textButton1.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton2 = document.getElementById("textButton2");
			if (textButton2) {
				textButton2.addEventListener("click", function (e) {
					window.location.href = "TeamPageDesktop.php";
				});
			}

			var textButton3 = document.getElementById("textButton3");
			if (textButton3) {
				textButton3.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton4 = document.getElementById("textButton4");
			if (textButton4) {
				textButton4.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton5 = document.getElementById("textButton5");
			if (textButton5) {
				textButton5.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					var anchor = document.querySelector("[data-scroll-to='header']");
					if (anchor) {
						anchor.scrollIntoView({ block: "start", behavior: "smooth" });
					}
				});
			}
			var loginButton = document.getElementById("loginButton");
			if (loginButton) {
				loginButton.addEventListener("click", function (e) {
					window.location.href = "./logout.php";
				});
			}
			var frameParent = document.querySelector(".frame-parent12");
			if (frameParent) {
				frameParent.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}
			var subContainer = document.querySelector(".sub-container44");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					window.scrollTo({
						top: 0,
						behavior: "smooth",
					});
				});
			}
		</script>
	</body>
</html>
