<?php
session_start();

	include("connection.php");
	include("functions.php");

		$user_data = check_login($con);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1, width=device-width" />

		<link rel="stylesheet" href="./global.css" />
		<link rel="stylesheet" href="./ContactPageDesktop.css" />
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Inter:wght@700&display=swap"
		/>
		<link
			rel="stylesheet"
			href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap"
		/>
	</head>
	<body>
		<div class="contact-page-desktop">
			<section class="contact-page-desktop-frame">
				<header class="navbar2">
					<div class="navbar-inner"></div>
					<div class="frame-container">
						<img
							class="frame-item"
							loading="lazy"
							alt=""
							src="./public/frame-2608168.svg"
						/>

						<h2 class="healthy-habits4">Healthy Habits</h2>
					</div>
					<div class="text-button-parent">
						<div class="text-button30" id="textButton9">Home</div>
						<div class="text-button31" id="textButton10">About</div>
						<div class="text-button32" id="textButton11">Tracker</div>
						<div class="text-button33" id="textButton12">Nutrition</div>
						<div class="text-button34" id="textButton13">Workouts</div>
						<div class="text-button-container">
							<div class="text-button35">Contact</div>
						</div>
						<button class="button18" id="button">
							<div class="text6">Logout</div>
						</button>
					</div>
				</header>
				<div class="container10">
					<div class="sub-container12">
						<img
							class="abstract-design-icon2"
							alt=""
							src="./public/abstract-design.svg"
						/>

						<button class="icon-container3">
							<img class="icon14" alt="" src="./public/icon.svg" />
						</button>
						<div class="text-container2">
							<h1 class="heading2">Contact Us</h1>
							<div class="paragraph">
								We value your feedback, questions, and concerns at Healthy
								Habits. Our dedicated team is here to assist you and provide the
								support you need on your nutritional journey. Please don't
								hesitate to reach out to us using any of the following contact
								methods
							</div>
						</div>
					</div>
					<div class="container11">
						<div class="buttons-container4">
							<div class="button19">
								<img class="icon15" alt="" src="./public/icon-11.svg" />

								<div class="icon-text-button">support@healthyhabits.com</div>
							</div>
							<div class="button20">
								<img class="icon15" alt="" src="./public/icon-21.svg" />

								<div class="text7">+91 00000 00000</div>
							</div>
							<div class="button20">
								<img class="icon15" alt="" src="./public/icon-31.svg" />

								<div class="text7">Denton, TX</div>
							</div>
						</div>
						<div class="container12">
							<div class="form1">
								<div class="form-elements2">
									<div class="container13">
										<div class="sub-container13">
											<div class="label6">Full Name</div>
											<div class="input-field5">
												<input
													class="sub-container14"
													placeholder="Enter your Name"
													type="text"
												/>
											</div>
										</div>
										<div class="sub-container13">
											<div class="label6">Email</div>
											<div class="input-field5">
												<input
													class="sub-container14"
													placeholder="Enter your Email"
													type="text"
												/>
											</div>
										</div>
									</div>
									<div class="container14">
										<div class="label6">Phone Number</div>
										<div class="input-field7">
											<input
												class="label-input-field"
												placeholder="Enter your Number"
												type="text"
											/>
										</div>
									</div>
									<div class="container15">
										<div class="container16">
											<div class="label6">Message</div>
											<textarea
												class="input-field8"
												placeholder="Enter your Message"
												rows="{7}"
												cols="{35}"
											>
											</textarea>
										</div>
										<div class="buttoncontainer">Max 250 Chars</div>
									</div>
								</div>
								<button class="button22">
									<div class="text10">Send Message</div>
								</button>
							</div>
							<div class="sub-container16">
								<img
									class="map-icon"
									loading="lazy"
									alt=""
									src="./public/map.svg"
								/>

								<div class="buttons-container5">
									<button class="button23">
										<img class="icon18" alt="" src="./public/icon-1.svg" />
									</button>
									<button class="button23">
										<img class="icon18" alt="" src="./public/icon-2.svg" />
									</button>
									<button class="button23">
										<img class="icon18" alt="" src="./public/icon-3.svg" />
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section class="cta-section">
				<div class="framecta">
					<div class="abstract-design-group">
						<img
							class="abstract-design-icon3"
							alt=""
							src="./public/abstract-design-1.svg"
						/>

						<h2 class="heading3">
							Are you ready to embark on a transformative journey towards better
							health and wellness?
						</h2>
					</div>
					<div class="paragraph1">
						Join us at Healthy Habits and let us guide you on the path to a
						healthier and happier you.
					</div>
				</div>
				<div class="framefooter">
					<img
						class="abstract-design-icon4"
						alt=""
						src="./public/abstract-design-2.svg"
					/>

					<button class="button26">
						<div class="c-t-a">Join Us Now</div>
					</button>
				</div>
			</section>
			<footer class="footer-section2">
				<div class="container17">
					<div class="logo2" id="logoContainer">
						<img class="frame-item" alt="" src="./public/frame-2608168.svg" />

						<h2 class="healthy-habits5">Healthy Habits</h2>
					</div>
					<div class="footer-text-button">
						<div class="text-button30" id="textButton">Home</div>
						<div class="text-button31" id="textButton1">About</div>
						<div class="text-button32" id="textButton2">Tracker</div>
						<div class="text-button39" id="textButton3">Nutrition</div>
						<div class="text-button40" id="textButton4">Workouts</div>
						<div class="text-button41" id="textButton5">Contact</div>
					</div>
					<div class="sub-container17" id="subContainer">
						<div class="sub-container-text">Go To Top</div>
						<button class="button27">
							<img
								class="icon15"
								alt=""
								src="./public/heroiconsminiarrowsmallup.svg"
							/>
						</button>
					</div>
				</div>
				<div class="container18">
					<div class="sub-container18">
						<div class="button28">
							<img class="icon21" alt="" src="./public/icon-4.svg" />

							<div class="text-button42">healthyhabits@my.unt.edu</div>
						</div>
						<button class="button29">
							<img class="icon21" alt="" src="./public/icon-5.svg" />

							<div class="text-button43">+91 91813 23 2309</div>
						</button>
						<button class="button29">
							<img class="icon21" alt="" src="./public/icon-6.svg" />

							<div class="text-button44">Denton, TX</div>
						</button>
					</div>
					<div class="sub-form-field">
						© 2024 Healthy Habits. All rights reserved.
					</div>
				</div>
			</footer>
		</div>

		<script>
			var textButton9 = document.getElementById("textButton9");
			if (textButton9) {
				textButton9.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton10 = document.getElementById("textButton10");
			if (textButton10) {
				textButton10.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton11 = document.getElementById("textButton11");
			if (textButton11) {
				textButton11.addEventListener("click", function (e) {
					window.location.href = "TrackerPage.php";
				});
			}

			var textButton12 = document.getElementById("textButton12");
			if (textButton12) {
				textButton12.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton13 = document.getElementById("textButton13");
			if (textButton13) {
				textButton13.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var button = document.getElementById("button");
			if (button) {
				button.addEventListener("click", function (e) {
					window.location.href = "./logout.php";
				});
			}

			var logoContainer = document.getElementById("logoContainer");
			if (logoContainer) {
				logoContainer.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton = document.getElementById("textButton");
			if (textButton) {
				textButton.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var textButton1 = document.getElementById("textButton1");
			if (textButton1) {
				textButton1.addEventListener("click", function (e) {
					window.location.href = "./AboutPageDesktop.php";
				});
			}

			var textButton2 = document.getElementById("textButton2");
			if (textButton2) {
				textButton2.addEventListener("click", function (e) {
					window.location.href = "./TeamPageDesktop.php";
				});
			}

			var textButton3 = document.getElementById("textButton3");
			if (textButton3) {
				textButton3.addEventListener("click", function (e) {
					window.location.href = "./NutritionPageDesktop.php";
				});
			}

			var textButton4 = document.getElementById("textButton4");
			if (textButton4) {
				textButton4.addEventListener("click", function (e) {
					window.location.href = "./WorkoutsPageDesktop.php";
				});
			}

			var textButton5 = document.getElementById("textButton5");
			if (textButton5) {
				textButton5.addEventListener("click", function (e) {
					window.location.href = "./ContactPageDesktop.php";
				});
			}

			var subContainer = document.getElementById("subContainer");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					var anchor = document.querySelector("[data-scroll-to='header']");
					if (anchor) {
						anchor.scrollIntoView({ block: "start", behavior: "smooth" });
					}
				});
			}

			var frameParent = document.querySelector(".frame-container");
			if (frameParent) {
				frameParent.addEventListener("click", function (e) {
					window.location.href = "./HomePageDesktop.php";
				});
			}

			var subContainer = document.querySelector(".sub-container17");
			if (subContainer) {
				subContainer.addEventListener("click", function () {
					window.scrollTo({
						top: 0,
						behavior: "smooth",
					});
				});
			}
		</script>
	</body>
</html>
